# Task 4

- [x] a.
- [ ] b.
- [ ] c.
- [x] d.
- [x] e.
- [ ] f.
- [ ] g.
